/*
 * CS252: Shell project
 *
 * Template file.
 * You will need to add more code here to execute the command table.
 *
 * NOTE: You are responsible for fixing any bugs this code may have!
 *
 * DO NOT PUT THIS PROJECT IN A PUBLIC REPOSITORY LIKE GIT. IF YOU WANT 
 * TO MAKE IT PUBLICALLY AVAILABLE YOU NEED TO REMOVE ANY SKELETON CODE 
 * AND REWRITE YOUR PROJECT SO IT IMPLEMENTS FUNCTIONALITY DIFFERENT THAN
 * WHAT IS SPECIFIED IN THE HANDOUT. WE OFTEN REUSE PART OF THE PROJECTS FROM  
 * SEMESTER TO SEMESTER AND PUTTING YOUR CODE IN A PUBLIC REPOSITORY
 * MAY FACILITATE ACADEMIC DISHONESTY.
 */

#include <cstdio>
#include <cstdlib>

#include <iostream>

#include "command.hh"
#include "shell.hh"

#include <cstring>

#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>


Command::Command() {
    // Initialize a new vector of Simple Commands
    _simpleCommands = std::vector<SimpleCommand *>();

    _outFile = NULL;
    _inFile = NULL;
    _errFile = NULL;
    _append = false;
    _background = false;
}

void Command::insertSimpleCommand( SimpleCommand * simpleCommand ) {
    // add the simple command to the vector
    _simpleCommands.push_back(simpleCommand);
}

void Command::clear() {
    // deallocate all the simple commands in the command vector
    for (auto simpleCommand : _simpleCommands) {
        delete simpleCommand;
    }

    // remove all references to the simple commands we've deallocated
    // (basically just sets the size to 0)
    _simpleCommands.clear();

    if ( _outFile ) {
        delete _outFile;
    }
    _outFile = NULL;

    if ( _inFile ) {
        delete _inFile;
    }
    _inFile = NULL;

    if ( _errFile ) {
        delete _errFile;
    }
    _errFile = NULL;

    _append = false;

    _background = false;
}

void Command::print() {
    printf("\n\n");
    printf("              COMMAND TABLE                \n");
    printf("\n");
    printf("  #   Simple Commands\n");
    printf("  --- ----------------------------------------------------------\n");

    int i = 0;
    // iterate over the simple commands and print them nicely
    for ( auto & simpleCommand : _simpleCommands ) {
        printf("  %-3d ", i++ );
        simpleCommand->print();
    }

    printf( "\n\n" );
    printf( "  Output       Input        Error        Background\n" );
    printf( "  ------------ ------------ ------------ ------------\n" );
    printf( "  %-12s %-12s %-12s %-12s\n",
            _outFile?_outFile->c_str():"default",
            _inFile?_inFile->c_str():"default",
            _errFile?_errFile->c_str():"default",
            _background?"YES":"NO");
    printf( "\n\n" );
}

void Command::execute() {
    // Don't do anything if there are no simple commands
    if ( _simpleCommands.size() == 0 ) {
        Shell::prompt();
        return;
    }

    // Print contents of Command data structure
    //print();

    // Add execution here
    // For every simple command fork a new process
    // Setup i/o redirection
    // and call exec
    for (unsigned int temp = 0; temp < _simpleCommands.size(); temp++) {
      //printf("Command %d is %s\n", temp, _simpleCommands[temp]->_arguments[0]->c_str());
    }

    //EXIT Command Line Procedure
    if (strcmp(_simpleCommands[0]->_arguments[0]->c_str(), "exit") == 0) {
      printf("Good Bye!\n");
      exit(0);
    }


    //SETENV Command Line Procedure
    if (strcmp(_simpleCommands[0]->_arguments[0]->c_str(), "setenv") == 0) {
      //printf("Doing setenv of %s, %s\n", _simpleCommands[0]->_arguments[1]->c_str(), _simpleCommands[0]->_arguments[2]->c_str());
      if(setenv(_simpleCommands[0]->_arguments[1]->c_str(), _simpleCommands[0]->_arguments[2]->c_str(), 1) != 0 ) {
        perror("setenv");
      }
      //printf("Completed setenv of %s\n", _simpleCommands[0]->_arguments[1]->c_str());
      //printf("%s\n", getenv(_simpleCommands[0]->_arguments[1]->c_str()));
    }

    //UNSETENV Command Line Procedure
    if (strcmp(_simpleCommands[0]->_arguments[0]->c_str(), "unsetenv") == 0) {
      if (unsetenv(_simpleCommands[0]->_arguments[1]->c_str()) != 0) {
        perror("unsetenv");
      }
    }

    //CD Command Line Procedure
    int cd_err;
    if (strcmp(_simpleCommands[0]->_arguments[0]->c_str(), "cd") == 0) {
      if (_simpleCommands[0]->_arguments.size() == 1 || !strcmp(_simpleCommands[0]->_arguments[1]->c_str(), "{HOME}")) {
        cd_err = chdir(getenv("HOME"));
      }
      //if(chdir(_simpleCommands[0]->_arguments[1]->c_str()) != 0) {
      else {
        cd_err = chdir(_simpleCommands[0]->_arguments[1]->c_str());
      }
      if (cd_err != 0) {
        fprintf(stderr, "cd: can't cd to %s\n", _simpleCommands[0]->_arguments[1]->c_str());
      }
    }

    //PRINTENV Command Line Procedure
    /*
    if (strcmp(_simpleCommands[0]->_arguments[0]->c_str(), "printenv") == 0) {
      char **p = environ;
      while (*p != NULL) {
        printf("%s\n", *p);
        p++;
      }
    }
    const char * command = _simpleCommands[0]->_arguments[0]->c_str();
    int argn = _simpleCommands[0]->_arguments.size();
    char ** args = new char*[argn+1];
    for (int j = 0; j < argn; j++) {
      args[j] = (char *)_simpleCommands[0]->_arguments[j]->c_str();
    }
    args[argn] = NULL;
    execvp(command, args);
    perror("execvp");
    exit(1);
    */
    //SOURCE Command Line Procedure
    if (strcmp(_simpleCommands[0]->_arguments[0]->c_str(), "source") == 0) {
      char * filename = new char[strlen(_simpleCommands[0]->_arguments[1]->c_str() + 1)];
      strcpy(filename, _simpleCommands[0]->_arguments[1]->c_str());
      clear();
      Shell::source(filename);
      clear();
      return;
    }

    int std_in = dup(0);
    int std_out = dup(1);
    int std_err = dup(2);

    int outFd = -1;
    int errFd = -1;
    int inFd = -1;

    pid_t pid;
    if (_inFile) {
      inFd = open(_inFile->c_str(), O_RDONLY);
    }
    else {
      inFd = dup(std_in);
    }
    outFd = dup(std_out);
    errFd = dup(std_err);
    
    for (unsigned int cmd = 0; cmd < _simpleCommands.size(); cmd++) {
      dup2(inFd, 0);
      close(inFd);
      dup2(std_out, 1);
      dup2(std_err, 2);
      //printf("Executing command %d outof %ld \n", cmd, _simpleCommands.size());
      int num_args = _simpleCommands[cmd]->_arguments.size();
      char ** argList = new char*[num_args + 1];
      if (cmd == _simpleCommands.size() - 1) {
        if (_outFile) {
          if (_append) {
            outFd = open(_outFile->c_str(), O_CREAT|O_WRONLY|O_APPEND, 0664);
          }
          else {
            outFd = open(_outFile->c_str(), O_CREAT|O_WRONLY|O_TRUNC, 0664);
          }
        }
        if (_errFile) {
          //printf("Errorfile created\n");
          if (_append) {
            errFd = open(_errFile->c_str(), O_CREAT|O_WRONLY|O_APPEND, 0664);
          }
          else {
            errFd = open(_errFile->c_str(), O_CREAT|O_WRONLY|O_TRUNC, 0664);
          }
        }
        //printf("File creation done \n");
      }
      else {
        int pipeDesc[2];
        pipe(pipeDesc);
        outFd = pipeDesc[1];
        inFd = pipeDesc[0];
      }
      //printf ("File Desc: %d : %d : %d\n", inFd, outFd, errFd);
      for (int i = 0; i < num_args; i++) {
        argList[i] = (char *)_simpleCommands[cmd]->_arguments[i]->c_str();
        //printf("%s\n", argList[i]);
      }
      argList[num_args] = NULL;

      char last_arg_str [2048];
      sprintf(last_arg_str, "%s", argList[num_args - 1]);
      setenv("_", last_arg_str, 1);

      //printf ("Forking\n");
      dup2(outFd, 1);
      close(outFd);
      dup2(errFd, 2);
      close(errFd);

      pid = fork();
      if (pid == -1) {
        perror("Error in fork\n");
        exit(-1);
      }
      else if (pid > 0) {
        //if there is no & specified, we will be waiting for the process to complete
        //and not running in the background
        /*
        if (!_background) {
          int c_process_status;
          waitpid(pid, &c_process_status, 0);
        }
        */
      }
      else {
       /*
        printf ("Execute Cmd: %s  with Arguments: ", _simpleCommands[cmd]->_arguments[0]->c_str());
        for (int i = 0; i < num_args; i++) {
          printf ("%s ", argList[i]);
        }
        printf ("\n");
        */
        /*
        if (!strcmp(_simpleCommands[cmd]->_arguments[0]->c_str(), "printenv")) {
          char **p = environ;
          while (*p!=NULL) {
            printf("%s\n", *p);
            p++;
          }
          exit(0);
        }
        */
        /*
        if (strcmp(_simpleCommands[0]->_arguments[0]->c_str(), "printenv") == 0) {
          char ** trav = environ;
          printf("Running printenv in the child command\n");
          while (*trav != NULL) {
            printf("%s\n", *trav);
            trav++;
          }
          exit(0);
        }*/
        execvp(_simpleCommands[cmd]->_arguments[0]->c_str(), argList);
        exit(1);
      }
    }


    dup2(std_in, 0);
    dup2(std_out, 1);
    dup2(std_err, 2);

    //takes stdin if value is 1 then terminal
    int isAtty = isatty(0);


    // Clear to prepare for next command
    if (!_background) {
      int c_process_status;
      waitpid(pid, &c_process_status, 0);
      char status_str [256];
      sprintf(status_str, "%d", WEXITSTATUS(c_process_status));
      setenv("?", status_str, 1);
    }
    else {
      Shell::backgroundpid.insert(pid);
      char process_str [128];
      sprintf(process_str, "%d", pid);
      setenv("!", process_str, 1);
    }
    //printf ("Coming out of commands loop\n");
    clear();

    // Print new prompt
    if (isAtty == 1) {
      Shell::prompt();
    }
}

SimpleCommand * Command::_currentSimpleCommand;
