#include <cstdio>

#include "shell.hh"
#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <iostream>
#include <fstream>
#include <unistd.h>

#define YY_BUFF_SIZE 32768

typedef struct yy_buffer_state * YY_BUFFER_STATE;
bool isPrompt = true;
int yyparse(void);
extern FILE * yyin;
YY_BUFFER_STATE yy_create_buffer(FILE * filepointer, int size);
void yypush_buffer_state(YY_BUFFER_STATE buffer);
void yypop_buffer_state();

//isPrompt = true;

void Shell::source(const char * filename) {
  FILE * fp = fopen(filename, "r");
  if (fp == NULL) {
    fprintf (stderr, "Source file %s not found/cannot open\n", filename);
    return;
  }
  isPrompt = false;
  //yyin = fp;
  yypush_buffer_state(yy_create_buffer(fp, YY_BUFF_SIZE));
  yyparse();
  fclose(fp);
  isPrompt = true;
  //yyin = stdin;
  yypop_buffer_state();
  prompt();
}

void Shell::prompt() {
  if (isatty(0)) {
    if (isPrompt == true) {
      printf("Best Shell>");
      //printf("Testing to see what is going on>");
      fflush(stdout);
    }
  }
}

extern "C" void disp(int sig) {
  fprintf(stderr, "\nsig: %d   Ouch!\n", sig);
  Shell::prompt();
}

extern "C" void zombie(int sig) {
  //printf("Zombie Elimination \n");
  if (sig == SIGCHLD) {
    int catchSignal = waitpid(-1, NULL, WNOHANG);
    while (catchSignal > 0) {
      if (Shell::backgroundpid.count(catchSignal) > 0) {
        printf("%d exited\n", catchSignal);
        Shell::backgroundpid.erase(catchSignal);
      }
      catchSignal = waitpid(-1, NULL, WNOHANG);
    }
  }
}


int main(int argc, char ** argv) {

  Shell::prompt();

  //implement the Ctrl-C logic:
  struct sigaction sa;
  sa.sa_handler = disp;
  sigemptyset(&sa.sa_mask);
  sa.sa_flags = SA_RESTART;
  if(sigaction(SIGINT, &sa, NULL)){
      perror("sigaction");
      exit(2);
  }

  char shell_path[512];
  realpath(argv[0], shell_path);
  setenv("SHELL", shell_path, 1);

  char pid_str[128];
  sprintf(pid_str, "%d", getpid());
  setenv("$", pid_str, 1);

  struct sigaction sa2;
  sa2.sa_handler = zombie;
  sigemptyset(&sa2.sa_mask);
  sa2.sa_flags = SA_RESTART;
  if (sigaction(SIGCHLD, &sa2, NULL)) {
    perror("sigaction");
    exit(2);
  }
  if( access( ".shellrc", F_OK ) == 0 ) {
    Shell::source(".shellrc");
  }
  yyparse();

}

Command Shell::_currentCommand;
std::set <int> Shell::backgroundpid;
