/**
 * The class representing a map.
 */
public class BeachLine extends Grid
{
	/**
	 * Constructor of the class.
	 */
	public BeachLine(String filepath)
	{
		super(filepath);
	}

	/**
	 * Finds the beach line by starting the search at (i, j).
	 * TO DO BY STUDENT
	 */
	public Pair[] findBeachLine(int i, int j) throws EmptyQueueException
	{
		super.print();
		Queue queue = new Queue(128);
		queue.enqueue(new Pair(i, j)); // ?Starting point placed in Queue
		boolean[][] visited = new boolean[super.nRows][super.nColumns];

		boolean land = (super.grid[i][j] == 1); // !For Testing
		Pair current = null; // *Starting point of traversal
		// *While loop to look for instance of land
		while (!queue.isEmpty()) {
			current = (Pair) queue.dequeue();
			visited[current.a][current.b] = true;
			if (super.grid[current.a][current.b] == 0) {
				// *Checks North and Enqueues
				if (current.a != 0) {
					if (!visited[current.a - 1][current.b]) {
						queue.enqueue(new Pair(current.a - 1, current.b));
						visited[current.a - 1][current.b] = true;
					}
				}
				// *Checks East and Enqueues
				if (current.b != super.nColumns - 1) {
					if (!visited[current.a][current.b + 1]) {
						queue.enqueue(new Pair(current.a, current.b + 1));
						visited[current.a][current.b + 1] = true;
					}
				}
				// *Checks South and Enqueues
				if (current.a != super.nRows - 1) {
					if (!visited[current.a + 1][current.b]) {
						queue.enqueue(new Pair(current.a + 1, current.b));
						visited[current.a + 1][current.b] = true;
					}
				}
				// *Checks West and Enqueues
				if (current.b != 0) {
					if (!visited[current.a][current.b - 1]) {
						queue.enqueue(new Pair(current.a, current.b - 1));
						visited[current.a][current.b - 1] = true;
					}
				}
			}
			else {
				break;
			}
		}
		queue = new Queue(128);
		visited = new boolean[super.nRows][super.nColumns];

		// *While statement for the first instance of water
		queue.enqueue(current);
		while (!queue.isEmpty()) {
			current = (Pair) queue.dequeue();
			visited[current.a][current.b] = true;
			if (super.grid[current.a][current.b] == 1) {
				// *Checks North and Enqueues
				if (current.a != 0) {
					if (!visited[current.a - 1][current.b]) {
						queue.enqueue(new Pair(current.a - 1, current.b));
						visited[current.a - 1][current.b] = true;
					}
				}
				// *Checks East and Enqueues
				if (current.b != super.nColumns - 1) {
					if (!visited[current.a][current.b + 1]) {
						queue.enqueue(new Pair(current.a, current.b + 1));
						visited[current.a][current.b + 1] = true;
					}
				}
				// *Checks South and Enqueues
				if (current.a != super.nRows - 1) {
					if (!visited[current.a + 1][current.b]) {
						queue.enqueue(new Pair(current.a + 1, current.b));
						visited[current.a + 1][current.b] = true;
					}
				}
				// *Checks West and Enqueues
				if (current.b != 0) {
					if (!visited[current.a][current.b - 1]) {
						queue.enqueue(new Pair(current.a, current.b - 1));
						visited[current.a][current.b - 1] = true;
					}
				}
			}
			else {
				break;
			}
		}

		// !Current is now the starting point of the water which is adjacent to the land
		Pair start = new Pair(current.a, current.b);
		Queue beachLine = new Queue();
		Pair bl_pair;
		beachLine.enqueue(start);
		short lastDir = 0; // * 1 - North, 2 - East, 3 - South, 4 - West

		do {
			// ?Checking for if South is land, then move East
			if ((current.a != super.nRows - 1) && (super.grid[current.a + 1][current.b] == 1)) {
				if ((current.b != super.nColumns - 1) && (super.grid[current.a][current.b + 1] == 0)) {
						current.b = (current.b + 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 2;
				} else {
					if (super.grid[current.a - 1][current.b] == 0) {
						current.a = (current.a - 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 1;
					} else {
						current.b = (current.b - 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 4;
					}
				}
			}


			// ?Checking for if North is land, then move West
			else if ((current.a != 0) && (super.grid[current.a - 1][current.b] == 1)) {
				if ((current.b != 0) && (super.grid[current.a][current.b - 1] == 0)) {
						current.b = (current.b - 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 4;
				} else {
					if (super.grid[current.a + 1][current.b] == 0) {
						current.a = (current.a + 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 3;
					} else {
						current.b = (current.b + 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 2;
					}
				}
			}


			// ?Checking to see if East is land, then move North
			else if ((current.b != super.nColumns - 1) && (super.grid[current.a][current.b + 1] == 1)) {
				if ((current.a != 0) && (super.grid[current.a - 1][current.b] == 0)) {
						current.a = (current.a - 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 1;
				} else {
					if (super.grid[current.a][current.b - 1] == 0) {
						current.b = (current.b - 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 4;
					} else {
						current.a = (current.a + 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 3;
					}
				}
			}

			// ?Checking to see if West is land, then move South
			else if ((current.b != 0) && (super.grid[current.a][current.b - 1] == 1)) {
				if ((current.a != super.nRows - 1) && (super.grid[current.a + 1][current.b] == 0)) {
						current.a = (current.a + 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 3;
				} else {
					if (super.grid[current.a][current.b + 1] == 0) {
						current.b = (current.b + 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 2;
					} else {
						current.a = (current.a - 1);
						bl_pair = new Pair(current.a, current.b);
						beachLine.enqueue(bl_pair);
						lastDir = 1;
					}
				}
			}
			// ?Checking for diagonal cases
			else {
				if (lastDir == 1) {
					current.b = (current.b + 1);
					bl_pair = new Pair(current.a, current.b);
					beachLine.enqueue(bl_pair);
				}
				else if (lastDir == 2) {
					current.a = (current.a + 1);
					bl_pair = new Pair(current.a, current.b);
					beachLine.enqueue(bl_pair);
				}
				else if (lastDir == 3) {
					current.b = (current.b - 1);
					bl_pair = new Pair(current.a, current.b);
					beachLine.enqueue(bl_pair);
				}
				else if (lastDir == 4) {
					current.a = (current.a - 1);
					bl_pair = new Pair(current.a, current.b);
					beachLine.enqueue(bl_pair);
				}
			}
		} while (!current.equals(start));

		Pair[] pairs = new Pair[beachLine.size() - 1];
		int size = beachLine.size() - 1;
		for (int k = 0; k < size; k++) {
			pairs[k] = (Pair) beachLine.dequeue();
		}
		return pairs;
	}


	/**
	 * Prints the content of the map.
	 */
	public void printMap() {
		for (int i = 0; i < nRows; i++) {
			for (int j = 0; j < nColumns; j++) {
				if (grid[i][j] == 0)
					System.out.print("\u2591 ");
				else
					System.out.print("\u2593 ");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		try {

			BeachLine B = new BeachLine(args[0]);

			if (args.length < 3) {
				B.printMap();
				return;
			}

			int a = Integer.parseInt(args[1]);
			int b = Integer.parseInt(args[2]);
			Pair[] line = B.findBeachLine(a, b);
			System.out.println(line.length);
			for (int i = 0; i < line.length; i++) {
				System.out.println(line[i].a + " " + line[i].b);
			}

		} catch (EmptyQueueException e) {
			System.out.println("Error in Queue implementation");
		}
	}
}
