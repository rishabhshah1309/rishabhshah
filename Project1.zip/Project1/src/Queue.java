public class Queue<Item> 
{
	Item[] array;
	private int head;
	private int tail;

	/**
	 * Constructor of the class.
	 * TO DO BY STUDENT
	 */
	public Queue()
	{
		array = (Item[]) new Object[1];
		head = 0;
		tail = 0;
	}

	/**
	 * Constructor of the class with initial capacity.
	 * TO DO BY STUDENT
	 */
	public Queue(int n)
	{
		array = (Item[]) new Object[n];
	}

	/**
	 * Dequeue the next item.
	 * TO DO BY STUDENT
	 */
	public Item dequeue() throws EmptyQueueException
	{
		if (array[head] == null) {
			throw new EmptyQueueException();
		}
		Item popped = array[head];
		array[head] = null;
		head = (head + 1) % array.length;
		// ?If the queue is 1/4 of the actual array, the size is halved
		if (size() - 1 < array.length / 4 && array.length > 1) {
			Item[] newArray = (Item[]) new Object[array.length / 2];
			for (int i = 0; i <= size(); i++) {
				newArray[i] = array[(i + head) % array.length];
			}
			head = 0;
			array = newArray;
			tail = size();
		}
		return popped;
	}

	/**
	 * Enqueues an item.
	 * TO DO BY STUDENT
	 */
	public void enqueue(Item item)
	{
		if (tail % array.length == head && array[head] != null)
		{
			Item[] newArray = (Item[]) new Object[2 * array.length];
			for (int i = 0; i < array.length; i++)
			{
				newArray[i] = array[(head + i) % array.length];
			}
			head = 0;
			tail = array.length;
			array = newArray;
			//System.out.println("enqueue array length: " + array.length);
		}
		array[tail] = item;
		tail = (tail + 1) % array.length;
	}

	/**
	 * Returns the array with the content of the queue.
	 * DO NOT DELETE OR MODIFY. REQUIRED FOR TESTING AND GRADING. ANY MODIFICATION OF THIS FUNCTION
	 * WILL BE CONSIDERED ACADEMIC DISHONESTY AND PENALIZED WITH 0 FOR THE ENTIRE PROJECT.
	 */
	public Item[] getArray()
	{
		return array;
	}

	/**
	 * Indicates whether the queue is empty or not.
	 * TO DO BY STUDENT
	 */
	public boolean isEmpty()
	{
		return size() == 0;
	}

	/**
	 * Peeks the next item to be dequeued.
	 * TO DO BY STUDENT
	 */
	public Item peek() throws EmptyQueueException
	{
		if (array[head] == null) {
			throw new EmptyQueueException();
		}
		return array[head];
	}

	/**
	 * Returns the size of the queue.
	 * TO DO BY STUDENT
	 */
	public int size()
	{
		int size = 0;
		for (int i=0; i<array.length; i++)
		{
			if(array[i]!=null)
			{
				size++;
			}
		}
		return size;
	}
}
