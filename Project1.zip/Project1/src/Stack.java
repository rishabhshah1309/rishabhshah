public class Stack<Item> 
{
	// The pointer to the first node of the stack
	private StackNode<Item> head;
	
	/**
	 * Constructor of the class.
	 * TO DO BY STUDENT
	 */
	public Stack() {
        head = null;
    
	}
	
	/**
	 * Indicates whether the stack is empty or not.
	 * TO DO BY STUDENT
	 */
	public boolean isEmpty() {
	    if (size() == 0) {
            return true;
        }
        return false;
	}
	
	/**
	 * Peeks the item at the top of the stack.
	 * TO DO BY STUDENT
	 */
	public Item peek() throws EmptyStackException {
		if (isEmpty()) {
            throw new EmptyStackException();
        }
        return head.item;
	}
	
	/**
	 * Pops the item at the top of the stack.
	 * TO DO BY STUDENT
	 */
	public Item pop() throws EmptyStackException {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        StackNode poppedItem = head;
        head = head.next;
        return (Item) poppedItem.item;
	}
	
	/**
	 * Pushes an item into the stack.
	 * TO DO BY STUDENT
	 */
	public void push(Item item) {
        StackNode<Item> current = new StackNode(item);
        current.next = head;
        head = current;
	}
	
	/**
	 * Returns the number of items in the stack.
	 * TO DO BY STUDENT
	 */
	public int size() {
		StackNode<Item> current = head;
        int size = 0;
        while (current != null) {
            current = current.next;
            size++;
        }
        return size;
	}

}
