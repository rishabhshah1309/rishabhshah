/**
 * The class representing a maze.
 */
public class Maze extends Grid {
	/**
	 * Constructor of the class.
	 */
	Stack stack = new Stack<Pair>();
	int[][] checked = new int[super.nRows][super.nColumns];

	public Maze(String filepath) {
		super(filepath);
	}

	/**
	 * Finds a path in the maze from (i1, j1) to (i2, j2). If no path then return null.
	 * TO DO BY STUDENT
	 */
	public Pair[] findPath(int i1, int j1, int i2, int j2) throws EmptyStackException {
		if (checked[i1][j1] == 1)
			return null;
		stack.push(new Pair(i1, j1));
		checked[i1][j1] = 1;

		if ((i1 == i2) && (j1 == j2)) {
			Pair[] pair = new Pair[stack.size()];
			while(stack.size() != 0)
				pair[stack.size() - 1] = (Pair) stack.pop();
			return pair;
		}
		int[] dirs = new int[4];
		// * 1 - North, 2 - East, 3 - South, 4 - West
		String string = "0000" + Integer.toBinaryString(super.grid[i1][j1]);
		string = string.substring(string.length() - 4);
		int j = 0;
		for(int i = 0; i < string.length(); i++) {
			if(string.charAt(i) == '1') {
				if(i == 0) {
					dirs[j++] = 4;
				}
				if(i == 1) {
					dirs[j++] = 2;
				}
				if(i == 2) {
					dirs[j++] = 3;
				}
				if(i == 3) {
					dirs[j++] = 1;
				}
			}
		}

		Pair[] pairs = null;
		for (int i = 0; i < dirs.length; i++) {
			if(pairs != null) {
				break;
			}
			if(dirs[i] == 1) {
				pairs = findPath(i1 - 1, j1, i2, j2);
			}
			else if(dirs[i] == 2) {
				pairs = findPath(i1, j1 + 1, i2, j2);
			}
			else if(dirs[i] == 3) {
				pairs = findPath(i1 + 1, j1, i2, j2);
			}
			else if(dirs[i] == 4) {
				pairs = findPath(i1 , j1 - 1, i2, j2);
			}
		}
		if (pairs == null)
			stack.pop();
		return pairs;
	}

	/**
	 * Prints the contents of the maze.
	 */
	public void printMaze()
	{
		for (int i = 0; i < nRows; i += 1)
		{
			for (int j = 0; j < nColumns; j += 1)
			{
				if ((grid[i][j] & Direction.NORTH.getBit()) == 0)
				{
					System.out.print("+---");
				}
				else
				{
					System.out.print("+   ");
				}
			}

			System.out.println("+");

			for (int j = 0; j < nColumns; j += 1)
			{
				if ((grid[i][j] & Direction.WEST.getBit()) == 0)
				{
					System.out.print("|   ");
				}
				else
				{
					System.out.print("    ");
				}
			}

			System.out.println("|");
		}

		for (int j = 0; j < nColumns; j += 1)
		{
			System.out.print("+---");
		}

		System.out.println("+");
	}

	public static void main(String[] args) {

		try {

			Maze m = new Maze(args[0]);

			if (args.length < 5) {
				m.printMaze();
				return;
			}

			int i1 = Integer.parseInt(args[1]);
			int j1 = Integer.parseInt(args[2]);
			int i2 = Integer.parseInt(args[3]);
			int j2 = Integer.parseInt(args[4]);

			Pair[] path = m.findPath(i1, j1, i2, j2);
			if (path == null) {
				System.out.println("no path");
				return;
			}

			System.out.println(path.length);
			for (int i = 0; i < path.length; i++) {
				System.out.println(path[i].a + " " + path[i].b);
			}

		} catch (EmptyStackException e) {
			System.out.println("Error in Queue implementation");
		}
	}
}

