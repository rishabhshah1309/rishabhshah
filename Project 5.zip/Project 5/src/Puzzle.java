import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Arrays;
import java.util.Scanner;
import java.io.File;
public class Puzzle {
    int n; // *Size of the matrix
    char wordSearch[][];
    String word; // *The word we are looking for
    int x; // *The final x-coordinate of the word we are looking for
    int y; // *The final y-coordinate of the word we are looking for

    boolean flag = false;
    boolean temp_flag = false;

    //
	// constructor: fn is the filename where the puzzle is stored
	//
    public Puzzle(String fn) {
    	//TO BE IMPLEMENTED
        try {
            File file = new File(fn);
            Scanner sc = new Scanner(file);

            // *Read in the n value to find the size of the matrix
            n = sc.nextInt();
            sc.nextLine();

            // *Define the wordsearch matrix with the n parameter
            wordSearch = new char[n][n];

            // *Loop through the text file and fill out the character array
            for (int i = 0; i < n; i++) {
                String line = sc.next();
                for (int j = 0; j < n; j++) {
                    // *Filling out the the word search matrix with the character
                    wordSearch[i][j] = line.charAt(j);
                }
                sc.nextLine();
            }

        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        for (int i = 0; i < n; i++) {
            System.out.println(Arrays.toString(wordSearch[i]));
        }


    }

    //
    // search the puzzle for the given word
    // return {a, b, x, y} where (a, b) is
    // the starting location and (x, y) is 
    // the ending location
    // return null if the word can't be found
    // in the puzzle
    //


    // *Need to check in all 8 directions
    // *    NW  N  NE
    // *     W  L  E    --> L indicates the letter of interest
    // *    SW  S  SE

    // ?Check to see if the letter is moving towards the north west
    // *Letter is the next corresponding letter in the word
    // *x is the x-coordinate of the last location
    // *y is the y-coordinate of the last location

    // ?Is it northWest
    public boolean northWest(String word, int x, int y) {

        // * Now to check for the word in the matrix
        if (word.length() == 1) {
            if(word.charAt(0) == wordSearch[x][y]) {
                flag = true;
                return true;
            }
            else {
                return false;
            }
        }

        // * Checking for out of bounds
        if (x == 0) {
            return false;
        }
        if (y == 0) {
            return false;
        }

        if (word.charAt(1) == wordSearch[x - 1][y - 1]) {
            this.x = x - 1; // *Update the location of x
            this.y = y - 1; // *Update the location of y
            northWest(word.substring(1), x - 1, y - 1);
        }
        return false;
    }
    // ?Is it north
    public boolean north(String word, int x, int y) {

        // * Now to check for the word in the matrix
        if (word.length() == 1) {
            if(word.charAt(0) == wordSearch[x][y]) {
                flag = true;
                return true;
            }
            else {
                return false;
            }
        }

        // * Checking for out of bounds
        if (x == 0) {
            return false;
        }

        if (word.charAt(1) == wordSearch[x - 1][y]) {
            this.x = x - 1; // *Update the location of x
            north(word.substring(1), x - 1, y);
        }
        return false;
    }
    // ?Is it northEast
    public boolean northEast(String word, int x, int y) {


        // * Now to check for the word in the matrix
        //System.out.printf("Checking %s at index(%d, %d)\n", word, x, y);
        if (word.length() == 1) {
            if(word.charAt(0) == wordSearch[x][y]) {
                flag = true;
                return true;
            }
            else {
                return false;
            }
        }

        // * Checking for out of bounds
        if (x == 0) {
            return false;
        }
        if (y == wordSearch.length - 1) {
            return false;
        }

        if (word.charAt(1) == wordSearch[x - 1][y + 1]) {
            this.x = x - 1; // *Update the locaiton of x
            this.y = y + 1; // *Update the location of y
            //System.out.println("Index x: " + x + " " + "index y: " + y);
            temp_flag = true;
            northEast(word.substring(1), x - 1, y + 1);
        }
        return false;
    }
    // ?Is it west
    public boolean west(String word, int x, int y) {

        // * Now to check for the word in the matrix
        if (word.length() == 1) {
            if(word.charAt(0) == wordSearch[x][y]) {
                flag = true;
                return true;
            }
            else {
                return false;
            }
        }

        // * Checking for out of bounds
        if (y == 0) {
            return false;
        }

        if (word.charAt(1) == wordSearch[x][y - 1]) {
            this.y = y - 1; // *Update the location of y
            west(word.substring(1), x, y - 1);
        }
        return false;
    }
    // ?Is it east
    public boolean east(String word, int x, int y) {

        // * Now to check for the word in the matrix
        if (word.length() == 1) {
            if(word.charAt(0) == wordSearch[x][y]) {
                flag = true;
                return true;
            }
            else {
                return false;
            }
        }

        // * Checking for out of bounds
        if (y == wordSearch.length - 1) {
            return false;
        }

        if (word.charAt(1) == wordSearch[x][y + 1]) {
            this.y = y + 1; // *Update the location of y
            east(word.substring(1), x, y + 1);
        }
        return false;
    }
    // ?Is it southWest
    public boolean southWest(String word, int x, int y) {

        if (y == 0) {
            return false;
        }

        // * Checking for out of bounds
        if (x == wordSearch.length - 1) {
            return false;
        }

        if (word.length() == 1) {
            if(word.charAt(0) == wordSearch[x][y]) {
                flag = true;
                return true;
            }
            else {
                return false;
            }
        }
        if (word.charAt(1) == wordSearch[x + 1][y - 1]) {
            this.x = x + 1; // *Update the location of x
            this.y = y - 1; // *Update the location of y
            southWest(word.substring(1), x + 1, y - 1);
        }
        return false;
    }
    // ?Is it south
    public boolean south(String word, int x, int y) {

        if (word.length() == 1) {
            if(word.charAt(0) == wordSearch[x][y]) {
                flag = true;
                return true;
            }
            else {
                return false;
            }
        }

        // * Checking for out of bounds
        if (x == wordSearch.length - 1) {
            return false;
        }


        if (word.charAt(1) == wordSearch[x + 1][y]) {
            this.x = x + 1; // *Update the location of y
            south(word.substring(1), x + 1, y);
        }
        return false;
    }
    // ?Is it southEast
    public boolean southEast(String word, int x, int y) {
        if (word.length() == 1) {
            if(word.charAt(0) == wordSearch[x][y]) {
                flag = true;
                return true;
            }
            else {
                return false;
            }
        }

        // * Checking for out of bounds
        if (x == wordSearch.length - 1) {
            return false;
        }
        if (y == wordSearch.length - 1) {
            return false;
        }

        if (word.charAt(1) == wordSearch[x + 1][y + 1]) {
            this.x = x + 1; // *Update the location of x
            this.y = y + 1; // *Update the location of y
            southEast(word.substring(1), x + 1, y + 1);
        }
        return false;
    }


    public int[] search(String word)
    {
        this.word = word;
    	//TO BE IMPLEMENTED
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (word.charAt(0) == wordSearch[i][j]) {

                    x = i;
                    y = j;
                    northEast(word, i, j);
                    if (flag) {
                        int indexes[] = {i, j, x, y};
                        flag = false;
                        return indexes;
                    }


                    x = i;
                    y = j;
                    north(word, i, j);
                    if (flag) {
                        int indexes[] = {i, j, x, y};
                        flag = false;
                        return indexes;
                    }


                    x = i;
                    y = j;
                    northWest(word, i, j);
                    if (flag) {
                        int indexes[] = {i, j, x, y};
                        flag = false;
                        return indexes;
                    }


                    x = i;
                    y = j;
                    west(word, i ,j);
                    if (flag) {
                        int indexes[] = {i, j, x, y};
                        flag = false;
                        return indexes;
                    }



                    x = i;
                    y = j;
                    east(word, i, j);
                    if (flag) {
                        int indexes[] = {i, j, x, y};
                        flag = false;
                        return indexes;
                    }



                    x = i;
                    y = j;
                    southWest(word, i, j);
                    if (flag) {
                        int indexes[] = {i, j, x, y};
                        flag = false;
                        return indexes;
                    }


                    x = i;
                    y = j;
                    south(word, i, j);
                    if (flag) {
                        int indexes[] = {i, j, x, y};
                        flag = false;
                        return indexes;
                    }



                    x = i;
                    y = j;
                    southEast(word, i, j);
                    if (flag) {
                        int indexes[] = {i, j, x, y};
                        flag = false;
                        return indexes;
                    }
                    //System.out.println("Didn't find anything let's continue?");
                }
                //System.out.println("At index " + i + ", " + j);
            }
        }
        return null;
    }




}