import java.security.NoSuchAlgorithmException;

public class NewCustomerQueue {
    // !GIVEN
    private Customer[] array;
    private CBlockChain table;
    //constructor: set variables
    //capacity = initial capacity of array
    // *DONE
    public NewCustomerQueue(int capacity) {
        //TO BE COMPLETED
        //System.out.printf("Capacity const. = %d\n", capacity);
        array = new Customer[capacity];
        table = new CBlockChain(capacity);
        //System.out.printf("Array Length const. = %d\n", array.length);
    }

    public void print_branch(int n)
    {
        // print parents
        System.out.println("Branch @" + n + array[n].name() + array[n].toStringInvestTime());
        int p = (n-1)/2;
        while (p > 0) {
            System.out.println("Parent @" + p + array[p].name() + array[p].toStringInvestTime());
            p = (p-1)/2;
        }
        System.out.println("Parent @ 0" + array[0].name() + array[0].toStringInvestTime());
        int sz = size();
        for (int i = n+1; i < sz; i++)
            System.out.println("@ " + i + array[i].name() + array[i].toStringInvestTime());
    }
    public void check_tree(String s)
    {
        int sz = size();
        boolean error = false;
        int i, l, r;
        l = 0;
        r = 0;
        for (i = 0; i < sz/2; i++) {
            l = i * 2 + 1;
            r = i * 2 + 2;
            if ((l < sz) && (array[l].compareTo(array[i]) > 0)) {
                System.out.println(s + " Heap Broken at node " + i);
                error = true;
                break;
            }
            if ((r < sz) && (array[r].compareTo(array[i]) > 0)) {
                System.out.println(s + " Heap Broken at node " + i);
                error = true;
                break;
            }
        }
        if (error) {
            System.out.println("Node " + i + ": " + array[i].name() + " " + array[i].toStringInvestTime());
            if (l < sz)
                System.out.println("Node " + l + ": " + array[l].name() + " " + array[l].toStringInvestTime());
            if (r < sz)
                System.out.println("Node " + r + ": " + array[r].name() + " " + array[r].toStringInvestTime());
        }
    }
    //insert Customer c into queue
    //return the final index at which the customer is stored
    //return -1 if the customer could not be inserted
    // *DONE
    public int heapIns(int i)
    {
        // Find parent
        int parent = (i - 1) / 2;

        // For Max-Heap
        // If current node is greater than its parent
        // Swap both of them and call heapify again
        // for the parent
        if (array[i].compareTo(array[parent]) > 0) {
            swap(i, parent);

            // Recursively heapify the parent node
            return heapIns(parent);
        }
        else {
            return i;
        }

    }
    public int insert(Customer c) throws NoSuchAlgorithmException {
        //TO BE COMPLETED
        //System.out.println("Array length = " + array.length);
        //System.out.println("Array Size = " + size());
        table.put(c);
        if (isEmpty()) {
            array[0] = c;
            c.setPosInQueue(0);
            //System.out.println(c.toStringWithPos() + " added to queue");
            System.out.println("Insert " + c.name() + " " + c.posInQueue() + " " + c.toStringInvestTime());
            // table.put(c);
            return 0;
        }


        int i = size();
        if (i == array.length) {
            return -1;
        }
        array[i] = c;
        int current = i;
        // Heapify the new node following a
        // Bottom-up approach
        current = heapIns(i);
        /*
        c.setPosInQueue(current);
        while ((current > 0) && (array[current].compareTo(array[current/2]) > 0)) {
            swap(current, current/2);
            current = current/2;
        }

         */
        c.setPosInQueue(current);
        // table.put(c);
/*
        int s = size();
        for (int j = 0; j < s; j++) {
            System.out.print(array[j].toStringInvestTime() + " ");
        }
        System.out.println();
        System.out.println("Returning current = " + current + " adding value " + c.investment());
*/
        //System.out.println("Insert " + c.name() + " " + c.posInQueue() + " " + c.toStringInvestTime());
        // check_tree("insert");
        return current;

    }
    // ? Helper method to help swap the customers.
    public void swap(int pos1, int pos2) {
        Customer temp = array[pos1];
        array[pos1] = array[pos2];
        array[pos2] = temp;
        array[pos1].setPosInQueue(pos1);
        array[pos2].setPosInQueue(pos2);
    }

    //remove and return the customer with the highest investment value
    //if there are multiple customers with the same investment value,
    //return the one who arrived first
    // *DONE

    // To heapDel a subtree rooted with node i which is
    // an index in arr[].Nn is size of heap
    public void heapDel(int n, int i)
    {
        int largest = i; // Initialize largest as root
        int l = 2 * i + 1; // left = 2*i + 1
        int r = 2 * i + 2; // right = 2*i + 2


        if ( (l < n) && (r < n) &&
                (array[l].compareTo(array[largest]) > 0) && (array[r].compareTo(array[largest]) > 0) ) {
            if ((array[l].compareTo(array[r]) > 0) )
                largest = l;
            else
                largest = r;
        }
        else if (l < n && (array[l].compareTo(array[largest]) > 0))
            largest = l;
        else if (r < n && (array[r].compareTo(array[largest]) > 0))
            largest = r;

        /*
        // If left child is larger than root
        if (l < n && (array[l].compareTo(array[largest]) > 0))
            largest = l;

        // If right child is larger than largest so far
        if (r < n && (array[r].compareTo(array[largest]) > 0))
            largest = r;
        */
        // If largest is not root
        if (largest != i) {
            swap(i, largest);
            //array[i].setPosInQueue(largest);
            //array[largest].setPosInQueue(i);

            // Recursively heapify the affected sub-tree
            heapDel(n, largest);
        }
    }
    public Customer delMax() throws NoSuchAlgorithmException {
        //TO BE COMPLETED

        //int s = size();
        /*
        for (int j = 0; j < s; j++) {
            System.out.print(array[j].toStringInvestTime()+ " ");
        }
        System.out.println();
        */

        if (isEmpty()) {
            return null;
        }
        Customer first =  array[0];
        //moveLeft();
        array[0] = array[size() - 1];
        array[0].setPosInQueue(0);
        array[size() - 1] = null;
        heapDel(size(), 0);
        table.remove(first.name());
        first.setPosInQueue(-1);
        //System.out.print("Del: " + first.name() + " QRoot:{");
      /*
        int sz = size();

        for(int i = 0; i < sz; i++) {
            if (array[i] != null)
                System.out.print(i + ": " +array[i].name() + "(" + array[i].toStringInvestTime() + "), ");
        }
        System.out.println("}");
      */
        //check_tree("delMax");
        return first;
    }
    // ?Helper method to move the array down one to the left
    // ?after deleting the max.
    public void moveLeft() {
        int numCust = size();
        for (int i = 1; i < numCust; i++) {
            array[i-1] = array[i];
            array[i-1].setPosInQueue(i-1);
        }
        array[numCust - 1] = null;
    }



    //return but do not remove the first customer in the queue
    // *DONE
    public Customer getMax() {
        //TO BE COMPLETED
        if (!(isEmpty())) {
            return array[0];
        }
        else {
            return null;
        }
    }

    //return the number of customers currently in the queue
    // *DONE
    public int size() {
        //TO BE COMPLETED
        int customers = 0;
        for(int i = 0; i < array.length; i++) {
            if (array[i] != null) {
                customers++;
            }
        }
        return customers;
    }

    //return true if the queue is empty; false else
    // *DONE
    public boolean isEmpty() {
        //TO BE COMPLETED
        return (size() == 0);
    }

    //used for testing underlying data structure
    public Customer[] getArray() {
        return array;
    }
    /*TO BE COMPLETED IN PART 2*/

    //remove and return the Customer with
    //name s from the queue
    //return null if the Customer isn't in the queue
    public Customer remove(String s) throws NoSuchAlgorithmException {
        //TO BE COMPLETED

        //System.out.println("Name to remove " + s);
        Customer cust = null;
        int size = size();
        int i;
        for (i = 0; i < size; i++) {
            if ((array[i] != null) && (array[i].name().equals(s))) {
                cust = array[i];
                //print_branch(i);
                array[i] = array[size() - 1];
                array[i].setPosInQueue(i);
                array[size() - 1] = null;
                int p = (i-1)/2;
                int n = i;
                while (p > 0) {
                    if ((array[n] != null) && (array[n].compareTo(array[p]) > 0)) {
                        swap(n, p);
                        n = p;
                        p = (p - 1) / 2;
                    } else {
                        break;
                    }
                }
                if ((array[n] != null) && (array[n].compareTo(array[0]) > 0)) {
                    swap(n, 0);
                    n = 0;
                }
                cust.setPosInQueue(-1);
                heapDel(size(), n);
                break;
            }
        }
        /*
        for (Customer c : array) {
            System.out.printf ("%d:%s ", c.posInQueue(), c.name());
        }
        System.out.println();

         */
        table.remove(cust.name());
        //   check_tree("remove (" +  cust.name() + " @ " + i + ")" );
        return cust;


    }

    //update the emergency lexvel of the Customer
    //with name s to investment
    public void update(String s, int investment) throws NoSuchAlgorithmException {
        //TO BE COMPLETED
        System.out.println("Starting update " + s);
        Customer updated = (Customer) remove(s);
        updated.setInvestment(investment);
        insert(updated);
        table.get(updated.name()).setInvestment(investment);
        // check_tree("update");
    }
}
    