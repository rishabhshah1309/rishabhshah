import java.security.NoSuchAlgorithmException;
import java.util.Random;

public class CreditUnion {

    private NewCustomerQueue cq;
    private int cr_threshold;
    private int capacity;
    private int processed = 0;
    private int seenByManager = 0;
    private int sentToBank = 0;
    private int walkedOut = 0;

    private int processCalled = 0;

    public CreditUnion(int cap, int cr_threshold) {
        //TO BE COMPLETED
        cq = new NewCustomerQueue(cap);
        capacity = cap;
        this.cr_threshold = cr_threshold;
    }

    public int cr_threshold() {
        return this.cr_threshold;
    }

    public int capacity() {
        return this.capacity;
    }

    /*process a new Customer:
     *if their investment value is higher than the cr_threshold,
     *send them directly to the emergency room and return null
     *otherwise, try to insert them into the queue
     *if the queue is full, compare their investment to the highest
     *investment currently in the queue; if their investment is higher,
     *send them to the Bank and return null; if the current max
     *is higher, send the max Customer to the Bank, insert
     *the new Customer into the queue, and return the name
     *of the max Customer
     */
    public String process(String name, int investment) throws NoSuchAlgorithmException {
        //TO BE COMPLETED
        //processed++;
        Customer c = new Customer(name, investment, System.currentTimeMillis());
        System.out.println("Process called " + ++processCalled );
        if (investment > cr_threshold) {
            sendToBank(c);
            processed++;
            return null;
        }
        if (cq.size() == capacity) {
            if (c.investment() > cq.getMax().investment()) {
                processed++;
                cq.remove(c.name());
                sendToBank(c);
                return null;
            }
            else {
                Customer cMax = cq.delMax();
                cq.remove(c.name());
                sendToBank(cMax);
                cq.insert(c);
                processed++;
                return cMax.name();
            }
        }
        else {
            cq.insert(c);
            processed++;
            return c.name();
        }
    }

    /*a Manager is available--send the Customer with
     *highest investment value to be seen; return the name
     *of the Customer or null if the queue is empty*/
    public String seeNext() throws NoSuchAlgorithmException {
        //TO BE COMPLETED
        if(cq.isEmpty()==true){
            return null;
        }
        Customer c = cq.delMax();
        seeManager(c);
        return c.name();
    }

    /*Customer experiences an emergency, raising their
     *investment value; if the investment value exceeds the
     *cr_threshold, send them directly to the bank;
     *else update their investment value in the queue;
     *return true if the Customer is removed from the queue
     *and false otherwise
     */
    public boolean handle_emergency(String name) throws NoSuchAlgorithmException {
        //TO BE COMPLETED
        // *Find the customer in the queue given the name
        int size = cq.size();
        Customer c = null;

        for (int i = 0; i < size; i++) {
            if ((cq.getArray()[i] != null) && (cq.getArray()[i].name().equals(name))) {
                c = cq.getArray()[i];
                break;
            }
        }
        if (c == null) {
            return false;
        }
        else {
            System.out.println("Customer not null " + c.name());
        }
        Random rand = new Random();
        int a = rand.nextInt(2);
        int b = rand.nextInt(10) + 1;
        // * LOSS
        if (a < 0.5) {
            c.setInvestment((int) (c.investment() * (1.0 - (b/100.0))));
        }
        // *Profit
        else {
            c.setInvestment((int) (c.investment() * (1.0 + (b/100.0))));
        }

        if (c == null) {
            return false;
        }

        if (c.investment() > cr_threshold) {
            cq.remove(c.name());
            sendToBank(c);
            return true;
        }
        if (c.investment() < 0) {
            walk_out(c.name());
            return true;
        }
        cq.update(c.name(), c.investment());
        return false;
    }

    /*Customer decides to walk out
     *remove them from the queue*/
    public void walk_out(String name) throws NoSuchAlgorithmException {
        //TO BE COMPLETED
        cq.remove(name);
        walkedOut++;
    }

    /*Indicates that Customer c has been sent to the Bank*/
    private void sendToBank(Customer c) {
        System.out.println("Customer " + c + " sent to Bank.");
        sentToBank++;
    }

    /*Indicates that a Customer is being seen by a Manager*/
    private void seeManager(Customer c) {
        System.out.println("Customer " + c + " is seeing a manager.");
        seenByManager++;
    }

    public int processed() {
        return processed;
    }

    public int sentToBank() {
        return sentToBank;
    }

    public int seenByManager() {
        return seenByManager;
    }

    public int walkedOut() {
        return walkedOut;
    }
}