import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.security.MessageDigest;

public class CBlockChain {
    private ArrayList[] table;
    private int size = 0;

    // *Hash map Name to SHA-256 type
    public byte[] getSHA(String input) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(input.getBytes(StandardCharsets.UTF_8));
    }

    public  String toHexString(byte[] hash) {
        BigInteger number = new BigInteger(1, hash);
        StringBuilder hexString = new StringBuilder(number.toString(16));
        while (hexString.length() < 32) {
            hexString.insert(0, '0');
        }
        return hexString.toString();
    }

    //set the table size to the first 
    //prime number p >= capacity
    public CBlockChain(int capacity) {
        //TO BE COMPLETED
        table = new ArrayList[getNextPrime(capacity)];
    }

    //return the Customer with the given name
    //or null if the Customer is not in the table
    // *if the customer's name is in the table then return the position
    // *of customer in the table.
    public Customer get(String name) throws NoSuchAlgorithmException {
        //TO BE COMPLETED
        byte[] SHA = getSHA(name);
        String hexString = toHexString(SHA);

        int h = name.hashCode() % table.length;
        if (h < 0) {
            h += table.length;
        }
        if (table[h] == null)
            return null;
        for(int i = 0; i < table[h].size(); i++) {
            if (toHexString(getSHA(((Customer)table[h].get(i)).name())).equals(hexString)) {
                return ((Customer)table[h].get(i));
            }
        }
        return null;
    }

    //put Customer c into the table
    // *if the get of customer is null then dont put
    public void put(Customer c) throws NoSuchAlgorithmException {
        //TO BE COMPLETED
        int h = c.name().hashCode() % table.length;
        if (h < 0) {
            h += table.length;
        }
        // *If there's no value in the h'th index of the table
        // *we must initailize the array list and put the customer in there
        if (table[h] == null) {
            table[h] = new ArrayList();
            table[h].add(c);
        }
        if (get(c.name()) == null) {
            table[h].add(c);
        }
        size++;
    }

    //remove and return the Customer with the given name
    //from the table
    //return null if Customer doesn't exist
    // *if the get is null then dont remove
    public Customer remove(String name) throws NoSuchAlgorithmException {
        //TO BE COMPLETED
        int h = name.hashCode() % table.length;
        if (h < 0) {
            h += table.length;
        }
        if (get(name) == null) {
            return null;
        }
        Customer c = get(name);
        table[h].remove(get(name));
        size--;
        return c;
    }

    //return the number of Customers in the table
    public int size() {
        //TO BE COMPLETED
        return size;
    }

    //returns the underlying structure for testing
    public ArrayList<Customer>[] getArray() {
        return table;
    }

    //get the next prime number p >= num
    private int getNextPrime(int num) {
        if (num == 2 || num == 3)
            return num;
        int rem = num % 6;
        switch (rem) {
            case 0:
            case 4:
                num++;
                break;
            case 2:
                num += 3;
                break;
            case 3:
                num += 2;
                break;
        }
        while (!isPrime(num)) {
            if (num % 6 == 5) {
                num += 2;
            } else {
                num += 4;
            }
        }
        return num;
    }


    //determines if a number > 3 is prime
    private boolean isPrime(int num) {
        if (num % 2 == 0) {
            return false;
        }

        int x = 3;
        for (int i = x; i < num; i += 2) {
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}
      

