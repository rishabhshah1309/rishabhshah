public class CustomerQueue {
    // !GIVEN
    private Customer[] array;

    //constructor: set variables
    //capacity = initial capacity of array
    // *DONE
    public CustomerQueue(int capacity) {
        //TO BE COMPLETED
        //System.out.printf("Capacity const. = %d\n", capacity);
        array = new Customer[capacity];
        //System.out.printf("Array Length const. = %d\n", array.length);
    }

    //insert Customer c into queue
    //return the final index at which the customer is stored
    //return -1 if the customer could not be inserted
    // *DONE
    public int heapIns(int i)
    {
        // Find parent
        int parent = (i - 1) / 2;

            // For Max-Heap
            // If current node is greater than its parent
            // Swap both of them and call heapify again
            // for the parent
        if (array[i].compareTo(array[parent]) > 0) {
            swap(i, parent);
            array[i].setPosInQueue(parent);
            array[parent].setPosInQueue(i);

            // Recursively heapify the parent node
            return heapIns(parent);
        }
        else {
            return i;
        }

    }
    public int insert(Customer c) {
        //TO BE COMPLETED
        //System.out.println("Array length = " + array.length);
        //System.out.println("Array Size = " + size());
        if (isEmpty()) {
            array[0] = c;
            c.setPosInQueue(0);
            //System.out.println(c.toStringWithPos() + " added to queue");
            return 0;
        }

        int i = size();
        if (i == array.length) {
            return -1;
        }
        array[i] = c;
        int current = i;
        // Heapify the new node following a
        // Bottom-up approach
        current = heapIns(i);
        /*
        c.setPosInQueue(current);
        while ((current > 0) && (array[current].compareTo(array[current/2]) > 0)) {
            swap(current, current/2);
            current = current/2;
        }

         */
        c.setPosInQueue(current);
/*
        int s = size();
        for (int j = 0; j < s; j++) {
            System.out.print(array[j].toStringInvestTime() + " ");
        }
        System.out.println();
        System.out.println("Returning current = " + current + " adding value " + c.investment());
*/
        return current;

    }
    // ? Helper method to help swap the customers.
    public void swap(int pos1, int pos2) {
        Customer temp = array[pos1];
        array[pos1] = array[pos2];
        array[pos2] = temp;
    }

    //remove and return the customer with the highest investment value
    //if there are multiple customers with the same investment value,
    //return the one who arrived first
    // *DONE

    // To heapDel a subtree rooted with node i which is
    // an index in arr[].Nn is size of heap
    public void heapDel(int n, int i)
    {
        int largest = i; // Initialize largest as root
        int l = 2 * i + 1; // left = 2*i + 1
        int r = 2 * i + 2; // right = 2*i + 2

        // If left child is larger than root
        if (l < n && (array[l].compareTo(array[largest]) > 0))
            largest = l;

        // If right child is larger than largest so far
        if (r < n && (array[r].compareTo(array[largest]) > 0))
            largest = r;

        // If largest is not root
        if (largest != i) {
            swap(i, largest);
            array[i].setPosInQueue(largest);
            array[largest].setPosInQueue(i);

            // Recursively heapify the affected sub-tree
            heapDel(n, largest);
        }
    }
    public Customer delMax() {
        //TO BE COMPLETED

        int s = size();
        /*
        for (int j = 0; j < s; j++) {
            System.out.print(array[j].toStringInvestTime()+ " ");
        }
        System.out.println();
        */

        if (isEmpty()) {
            return null;
        }
        Customer first =  array[0];
        //moveLeft();
        array[0] = array[size() - 1];
        array[size() - 1] = null;
        heapDel(size(), 0);

        return first;
    }
    // ?Helper method to move the array down one to the left
    // ?after deleting the max.
    public void moveLeft() {
        int numCust = size();
        for (int i = 1; i < numCust; i++) {
            array[i-1] = array[i];
            array[i-1].setPosInQueue(i-1);
        }
        array[numCust - 1] = null;
    }



    //return but do not remove the first customer in the queue
    // *DONE
    public Customer getMax() {
        //TO BE COMPLETED
        if (!(isEmpty())) {
            return array[0];
        }
        else {
            return null;
        }
    }

    //return the number of customers currently in the queue
    // *DONE
    public int size() {
        //TO BE COMPLETED
        int customers = 0;
        for(int i = 0; i < array.length; i++) {
            if (array[i] != null) {
                customers++;
            }
        }
        return customers;
    }

    //return true if the queue is empty; false else
    // *DONE
    public boolean isEmpty() {
        //TO BE COMPLETED
        return (size() == 0);
    }

    //used for testing underlying data structure
    public Customer[] getArray() {
        return array;
    }
}
    