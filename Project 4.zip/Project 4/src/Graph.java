import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;

public class Graph {

    // ? G_adj[x][y] = G_adj[y][x] = 1
    public int G_adj[][]; //adjacency matrix of the graph
    public double profit[]; //profits of each node
    public int n; //number of vertices

    // ? root_Mat[x][y] = 1 != root_Mat[y][x] --> x is a root, y is a child of the root
    public int root_Mat[][];
    // ? To check if the node is rooted
    public boolean rooted[];
    public int pebble = 0;
    public int notpebble = 0;
    double pebbled_vals[] = new double[n];
    double notpebbled_vals[] = new double[n];
    int pebbled[] = new int[n]; // ? 0 --> Not Determined
    // ! 1 --> Not Pebbled
    // * 2 --> Pebbled


    public ArrayList <Integer> visited  = new ArrayList<Integer>();
    public int count = 0;


    /**
     *  Take filename as parameter to the constructor
     *  The file contains graph information as follows
     *  first line contains, n, the number of vertices
     *  then there is a nxn matrix of 0s and 1s indicating the adjacency matrix
     *  finally there are n entries of double marking the profit
     *  store vertex number in a variable and load adjcency matrix information into a 2d array
     *  load profit information into an 1d array
     *  @param String filename
     */

    public Graph(String filename) throws FileNotFoundException {
        //implementations here
        File file = new File(filename);
        Scanner scanner = new Scanner(file);

        // *Read the number of verticies from the file
        if (scanner.hasNextLine()) {
            n = scanner.nextInt();
            scanner.nextLine();
        }

        // *Declare the adjacency matrix with the given n value
        G_adj = new int[n][n];
        // *Create a loop to go through the file and fill out the adjacency matrix
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                G_adj[i][j] = scanner.nextInt();
            }
            // *To go to the next line of the matrix, we need to call nextLine
            scanner.nextLine();
        }

        // *Declare profit array with given n value
        profit = new double[n];
        // *Fill out the profit values
        for (int i = 0; i < n; i++) {
            profit[i] = scanner.nextDouble();
        }

        // *Close the scanner after reading the entire file.
        scanner.nextLine();
        scanner.close();
    }



    /**
     * The function takes a vertex and finds the height of the tree subrooted at that vertex
     * To find the height of the entire tree you will pass the vertex at which the tree is rooted.(aka root of the tree)
     *
     * @param starting vertex V
     * @return height of the tree rooted at the vertex
     */
    public int height(int V){
        int h = heightRecur(V);
        visited.clear();
        return h;

    }
    public int heightRecur(int V) {
        int h = -1;
        // !Given an adjacency matrix and the size and specifications of the matrix
        // ?Find the DFS Traversal of the tree and find the longest path
        if (visited.contains(V)) {
            return -1;
        }
        visited.add(V);
        for (int j = 0; j < n; j++) {
            if (G_adj[V][j] == 1) {
                int hj = heightRecur(j);
                if (h < hj) {
                    h = hj;
                }
            }
        }
        h += 1;
        return h;
    }



    /**
     * The function takes a vertex that would be used to make rooted tree
     * make a rooted tree with V
     * Then write your implementations to find a set of vertices that returns maximum profit
     * @param starting vertex V
     * @return ArrayList of Integers
     */

    public void rootNode(int V) {
        if (rooted[V]) {
            return;
        }
        rooted[V] = true;
        for (int j = 0; j < n; j++) {
            if(G_adj[V][j] == 1 && !rooted[j]) {
                root_Mat[V][j] = 1;
                rootNode(j);
            }
        }
    }

    /*
    * Methods for pebbling that didnt make the cut
    public double pebbled(int V) {

        pebble += profit[V];
        for (int j = 0; j < n; j++) {
            if (root_Mat[V][j] == 1) {
                pebble += notPebbled(j);
            }
        }
        return pebble;
    }

    public double notPebbled(int V) {
        for (int j = 0; j < n; j++) {
            if (root_Mat[V][j] == 1) {
                double peb = pebbled(j);
                double notpeb = notPebbled(j);
                notpebble += (Math.max(peb, notpeb));
            }
        }
        return notpebble;
    }
     */

    public void setPebble(int V) {
        if (pebbled[V] == 0) {
            // * 0 is not determined
            if (pebbled_vals[V] > notpebbled_vals[V]) {
                pebbled[V] = 2;
                for (int j = 0; j < n; j++) {
                    if (root_Mat[V][j] == 1) {
                        pebbled[j] = 1;
                        setPebble(j);
                    }
                }
            }
            else {
                pebbled[V] = 1;
                for (int j = 0; j < n; j++) {
                    if (root_Mat[V][j] == 1) {
                        setPebble(j);
                    }
                }
            }
        }
        else if (pebbled[V] == 1) {
            // * 1 is not pebbled
            for (int j = 0; j < n; j++) {
                if (root_Mat[V][j] == 1) {
                    setPebble(j);
                }
            }
        }
        else if (pebbled[V] == 2) {
            // * 2 is pebbled
            for (int j = 0; j < n; j++) {
                if (root_Mat[V][j] == 1) {
                    pebbled[j] = 1;
                    setPebble(j);
                }
            }
        }
    }

    public void compute(int V) {
        boolean isLeaf = true;
        for (int j = 0; j < n; j++) {
            if (root_Mat[V][j] == 1) {
                isLeaf = false;
                compute(j);
            }
        }
        if (isLeaf) {
            //System.out.printf("Node %d is a leaf\n", V);
            pebbled_vals[V] = profit[V];
            notpebbled_vals[V] = 0;
        }
        else {
            pebbled_vals[V] = profit[V];
            notpebbled_vals[V] = 0;

            //System.out.printf("Computing for %d: ", V);

            for (int j = 0; j < n; j++) {
                if (root_Mat[V][j] == 1) {
                    //System.out.printf("%d ", j);
                    pebbled_vals[V] += notpebbled_vals[j];
                    notpebbled_vals[V] += ((pebbled_vals[j] > notpebbled_vals[j]) ? pebbled_vals[j] : notpebbled_vals[j]);
                }
            }
            //System.out.printf("Pebbled Val %f, Not Pebbled Val %f\n", pebbled_vals[V], notpebbled_vals[V]);
        }
    }

    public ArrayList<Integer> pebbling(int V){
        ArrayList<Integer> pebbled_list = new ArrayList<Integer>();
        //Implementations here
        // *STEP 1: Root the free tree
        // *Given Vertex V, we set that as the root and then find the path of children from
        // *that given node.
        root_Mat = new int[n][n];
        rooted = new boolean[n];
        rootNode(V);

        // *STEP 2: Find the pebbled and non-pebbled values of the root and its children
        // ?Pebbled is calculated by the profit of node U plus the sum of the non-pebbled entries of node U's children
        // ?If the node U is a leaf then the Pebbled value is simply just the profit of U.
        // ?Not-Pebbled is calculated by the sum of the max of Pebbled and Not-Pebbled entries for each of U's children
        // ?Not-Pebbled is 0 if Node U is a leaf.
        pebbled_vals = new double[n];
        notpebbled_vals = new double[n];
        compute(V);

        // *STEP 3: Find the maximum profit from the pebbled and not pebbled list
        pebbled = new int[n];
        setPebble(V);
        for (int i = 0; i < pebbled.length; i++) {
            if (pebbled[i] == 2) {
                pebbled_list.add(i);
            }
        }
        //System.out.println("Our solution is " + pebbled_list.toString());


        // !Printing pebbled and non-pebbled values for all the nodes
        for (int i = 0; i < n; i++) {
            //System.out.printf("Pebbled[%d]: %f, NotPebbled[%d]: %f\n", i, pebbled_vals[i], i, notpebbled_vals[i]);
        }

        return pebbled_list;
    }


    public static void main(String[] args) throws FileNotFoundException {
        // Check your implementation here
        // you d not need to implement this
        //System.out.println("Main function: ");
        //Graph graph = new Graph("task2input1.txt");
        //System.out.println(graph.n);
        //System.out.println(graph.G_adj[1].length + "x" + graph.G_adj.length);
        //System.out.println(graph.profit.length);
    }
}

