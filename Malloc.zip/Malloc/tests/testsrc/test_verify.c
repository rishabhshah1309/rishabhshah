#include "testing.h"

int main() {
  initialize_test(__FILE__);

  finalize_test();
}
